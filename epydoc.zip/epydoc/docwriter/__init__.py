# epydoc -- Output generation
#
# Copyright (C) 2005 Edward Loper
# Author: Edward Loper <edloper@loper.org>
# URL: <http://epydoc.sf.net>
#
# $Id: __init__.py 956 2006-03-10 01:30:51Z edloper $

"""
Output generation.
"""
__docformat__ = 'epytext en'
